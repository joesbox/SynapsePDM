/*  GSM.cpp GSM and GPS variables, functions and data handling.
    Copyright (c) 2025 Joe Mann.  All right reserved.

    This work is licensed under the Creative Commons
    Attribution-NonCommercial-ShareAlike 4.0 International License.
    To view a copy of this license, visit
    https://creativecommons.org/licenses/by-nc-sa/4.0/ or send a
    letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

    You are free to:
    - Share: Copy and redistribute the material in any medium or format.
    - Adapt: Remix, transform, and build upon the material.

    Under the following terms:
    - Attribution: You must give appropriate credit, provide a link to the license,
      and indicate if changes were made. You may do so in any reasonable manner,
      but not in any way that suggests the licensor endorses you or your use.
    - NonCommercial: You may not use the material for commercial purposes.
    - ShareAlike: If you remix, transform, or build upon the material,
      you must distribute your contributions under the same license as the original.

    DISCLAIMER: This software is provided "as is," without warranty of any kind,
    express or implied, including but not limited to the warranties of
    merchantability, fitness for a particular purpose, and noninfringement.
    In no event shall the authors or copyright holders be liable for any claim,
    damages, or other liability, whether in an action of contract, tort, or otherwise,
    arising from, out of, or in connection with the software or the use or
    other dealings in the software.
*/

#include "GSM.h"

#include "SIM7600G.h"
#define SERIAL_SIM7600G Serial1
#define BAUD_RATE 115200

SIM7600G sim7600(SERIAL_SIM7600G, BAUD_RATE);
uint32_t lastGPSTime = 0;
const uint32_t gpsUpdateInterval = 100; // 10Hz update rate
bool moduleReady = false;               // Track module initialization

float lat, lon, speed, alt, accuracy;
int vsat, usat, year, month, day, hour, minute, second;

bool GPSConnected = false;
bool simInitialized = false;
bool dataConnected = false;
bool GPSFix = false;

void InitialiseSIM()
{
    if (!simInitialized && sim7600.isModuleReady())
    {
        simInitialized = true;
        Serial.println("Initializing SIM...");
        sim7600.initializeSIM([](bool success, String response)
                              {
            if (success) {
                Serial.println("SIM initialized!");
                CheckSIMStatus();
            } else {
                Serial.println("Failed to initialize SIM.");
                Serial.println("Response: " + response);
            } });
    }
}

void CheckSIMStatus()
{
    Serial.println("Checking SIM status...");
    sim7600.checkSIMStatus([](bool success, String response)
                           {
        if (success) {
            Serial.println("SIM status checked!");
            EstablishDataConnection();
        } else {
            Serial.println("Failed to check SIM status.");
            Serial.println("Response: " + response);
        } });
}

void EstablishDataConnection()
{
    const char *apn = "three.co.uk";
    const char *user = "";
    const char *pass = "";

    Serial.println("Establishing data connection...");
    sim7600.establishDataConnection(apn, user, pass, [](bool success, String response)
                                    {
        if (success) {
            Serial.println("Data connection established!");
            dataConnected = true;
        } else {
            Serial.println("Failed to establish data connection.");
            Serial.println("Response: " + response);
        } });
}

void InitialiseGSM(bool enableData)
{
    pinMode(SIM_PWR, OUTPUT);
    pinMode(SIM_RST, OUTPUT);
    pinMode(SIM_FLIGHT, OUTPUT);

    digitalWrite(SIM_RST, LOW);
    digitalWrite(SIM_FLIGHT, LOW);

    // Power the module on
    digitalWrite(SIM_PWR, HIGH);
    delay(100);
    sim7600.begin();

    Serial.println("Initializing SIM7600G...");
}

void UpdateSIM7600()
{
    sim7600.update();
}

void UpdateGPS()
{
    if (!GPSConnected && sim7600.isModuleReady())
    {
        GPSConnected = true;
        Serial.println("Enabling GPS...");
        sim7600.enableGPS([](bool success, String response)
                          {
            if (success) {
                Serial.println("GPS enabled!");
            } else {
                Serial.println("Failed to enable GPS.");
                Serial.println("Response: " + response);
            } });
    }

    if (GPSConnected)
    {
        // Get GPS data
        sim7600.getGPSData([](bool success, String response)
                           {
            if (success) {
                lat = sim7600.latitude;
                lon = sim7600.longitude;
                speed = sim7600.speed;
                alt = sim7600.altitude;
                vsat = sim7600.satellites;
                usat = sim7600.satellites;                
                year = sim7600.year;
                month = sim7600.month;
                day = sim7600.day;
                hour = sim7600.hour;
                minute = sim7600.minute;
                second = sim7600.second;
            } else {
                Serial.println("Failed to get GPS data.");
                Serial.println("Response: " + response);
            } });
    }
    /*
    // TODO: Change NEMA update
    if (SerialAT.availableForWrite())
    {
      bool success = modem.getGPS(&lat, &lon, &speed, &alt, &vsat, &usat, &accuracy, &year, &month, &day, &hour, &minute, &second);

      if (success)
      {
        // Convert speed (knots) to preferred units
        switch (SystemParams.SpeedUnitPref)
        {
        case MPH:
          speed *= 1.15078F;
          break;

        case KPH:
          speed *= 1.852F;
          break;

        default:
          break;
        }

        // Convert distance to preferred units
        switch (SystemParams.DistanceUnitPref)
        {
        case Imperial:
          alt *= 3.28084;
          accuracy += 3.28084;
          break;
        case Metric:
          // No coversion required
          break;

        default:
          break;
        }
      }
    }*/
}

void HttpGet(const String &url)
{
    Serial.println("Performing HTTP GET request...");
    sim7600.httpGet(url, [](bool success, String response)
                    {
        if (success) {
            Serial.println("HTTP GET request successful!");
            Serial.println("Response: " + response);
        } else {
            Serial.println("Failed to perform HTTP GET request.");
            Serial.println("Response: " + response);
        } });
}

void HttpPost(const String &url, const String &data)
{
    Serial.println("Performing HTTP POST request...");
    sim7600.httpPost(url, data, [](bool success, String response)
                     {
        if (success) {
            Serial.println("HTTP POST request successful!");
            Serial.println("Response: " + response);
        } else {
            Serial.println("Failed to perform HTTP POST request.");
            Serial.println("Response: " + response);
        } });
}

void SendSMS(const String &number, const String &message)
{
    Serial.println("Sending SMS...");
    sim7600.sendSMS(number, message, [](bool success, String response)
                    {
        if (success) {
            Serial.println("SMS sent successfully!");
        } else {
            Serial.println("Failed to send SMS.");
            Serial.println("Response: " + response);
        } });
}

void MqttConnect(const String &server, int port)
{
    Serial.println("Connecting to MQTT server...");
    sim7600.mqttConnect(server, port, [](bool success, String response)
                        {
        if (success) {
            Serial.println("Connected to MQTT server!");
        } else {
            Serial.println("Failed to connect to MQTT server.");
            Serial.println("Response: " + response);
        } });
}

void MqttPublish(const String &topic, const String &message)
{
    Serial.println("Publishing MQTT message...");
    sim7600.mqttPublish(topic, message, [](bool success, String response)
                        {
        if (success) {
            Serial.println("MQTT message published!");
        } else {
            Serial.println("Failed to publish MQTT message.");
            Serial.println("Response: " + response);
        } });
}

void MqttSubscribe(const String &topic)
{
    Serial.println("Subscribing to MQTT topic...");
    sim7600.mqttSubscribe(topic, [](bool success, String response)
                          {
        if (success) {
            Serial.println("Subscribed to MQTT topic!");
        } else {
            Serial.println("Failed to subscribe to MQTT topic.");
            Serial.println("Response: " + response);
        } });
}
