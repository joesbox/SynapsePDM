/*  GSM.h GSM and GPS variables, functions and data handling.
    Copyright (c) 2025 Joe Mann.  All right reserved.

    This work is licensed under the Creative Commons
    Attribution-NonCommercial-ShareAlike 4.0 International License.
    To view a copy of this license, visit
    https://creativecommons.org/licenses/by-nc-sa/4.0/ or send a
    letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

    You are free to:
    - Share: Copy and redistribute the material in any medium or format.
    - Adapt: Remix, transform, and build upon the material.

    Under the following terms:
    - Attribution: You must give appropriate credit, provide a link to the license,
      and indicate if changes were made. You may do so in any reasonable manner,
      but not in any way that suggests the licensor endorses you or your use.
    - NonCommercial: You may not use the material for commercial purposes.
    - ShareAlike: If you remix, transform, or build upon the material,
      you must distribute your contributions under the same license as the original.

    DISCLAIMER: This software is provided "as is," without warranty of any kind,
    express or implied, including but not limited to the warranties of
    merchantability, fitness for a particular purpose, and noninfringement.
    In no event shall the authors or copyright holders be liable for any claim,
    damages, or other liability, whether in an action of contract, tort, or otherwise,
    arising from, out of, or in connection with the software or the use or
    other dealings in the software.
*/

#ifndef GSM_H
#define GSM_H

#include <Arduino.h>
#include <Globals.h>

/// @brief Initialise SIM7600G SIM card
void InitialiseSIM();

/// @brief Check SIM card status
void CheckSIMStatus();

/// @brief Establish data connection
void EstablishDataConnection();

/// @brief Initialise GSM/GPS
void InitialiseGSM(bool enableData);

/// @brief Update SIM7600G
void UpdateSIM7600();

/// @brief Update GPS info. Called periodically
void UpdateGPS();

/// @brief Get GPS data
void GetGPSData();

/// @brief Perform HTTP GET request
void HttpGet(const String &url);

/// @brief Perform HTTP POST request
void HttpPost(const String &url, const String &data);

/// @brief Send SMS
void SendSMS(const String &number, const String &message);

/// @brief Connect to MQTT server
void MqttConnect(const String &server, int port);

/// @brief Publish MQTT message
void MqttPublish(const String &topic, const String &message);

/// @brief Subscribe to MQTT topic
void MqttSubscribe(const String &topic);

/// @brief GPS connected flag
extern bool GPSConnected;

/// @brief GPS fix flag
extern bool GPSFix;

/// @brief Data connected flag
extern bool dataConnected;

/// @brief GPS Latitude
extern float lat;

/// @brief GPS Longitude
extern float lon;

/// @brief GPS Speed (default is knots)
extern float speed;

/// @brief GPS Altitude (default is metres);
extern float alt;

/// @brief GPS Accuracy
extern float accuracy;

/// @brief GPS Visible satellites
extern int vsat;

/// @brief GPS Used satellites
extern int usat;

/// @brief GPS Year
extern int year;

/// @brief GPS Month
extern int month;

/// @brief GPS Day
extern int day;

/// @brief GPS Hour
extern int hour;

/// @brief GPS Minute
extern int minute;

/// @brief GPS Second
extern int second;

#endif // GSM_H