#ifndef SIM7600G_H
#define SIM7600G_H

#include <Arduino.h>
#include <queue>

#define COMMAND_RETRIES 10

class SIM7600G
{
public:
    SIM7600G(HardwareSerial &serial, uint32_t baudRate = 115200);
    void begin();
    void update();
    void sendCommand(const String &command, const String &expectedResponse, uint32_t timeout, std::function<void(bool, String)> callback);
    bool isModuleReady() const { return moduleReady; }

    // GPS Functions
    void enableGPS(std::function<void(bool, String)> callback);
    void getGPSData(std::function<void(bool, String)> callback);
    void checkGPSFix(std::function<void(bool, String)> callback); 
    float latitude, longitude, speed, altitude, course;
    int satellites, year, month, day, hour, minute, second;

    // SIM and Data Functions
    void initializeSIM(std::function<void(bool, String)> callback);
    void checkSIMStatus(std::function<void(bool, String)> callback);
    void establishDataConnection(const char* apn, const char* user, const char* pass, std::function<void(bool, String)> callback);

    // HTTP/HTTPS Functions
    void httpGet(const String &url, std::function<void(bool, String)> callback);
    void httpPost(const String &url, const String &data, std::function<void(bool, String)> callback);

    // SMS Functions
    void sendSMS(const String &number, const String &message, std::function<void(bool, String)> callback);

    // MQTT/MQTTS Functions
    void mqttConnect(const String &server, int port, std::function<void(bool, String)> callback);
    void mqttPublish(const String &topic, const String &message, std::function<void(bool, String)> callback);
    void mqttSubscribe(const String &topic, std::function<void(bool, String)> callback);

    // Ping Function
    void ping(const String &host, std::function<void(bool, String)> callback);

private:
    struct Command
    {
        String command;
        String expectedResponse;
        uint32_t timeout;
        std::function<void(bool, String)> callback;
        uint32_t startTime;
        bool echoReceived;
        int retryCount; // Added retryCount field
    };

    HardwareSerial &SIMSerial;
    uint32_t baudRate;
    std::queue<Command> commandQueue;
    Command currentCommand;
    bool commandInProgress;
    String responseBuffer;
    bool moduleReady;
    uint32_t lastATAttempt;

    void processNextCommand();
    void parseGPSData(const String &response);
};

#endif // SIM7600G_H