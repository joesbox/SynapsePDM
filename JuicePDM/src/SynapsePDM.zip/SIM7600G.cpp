#include "SIM7600G.h"

SIM7600G::SIM7600G(HardwareSerial &serial, uint32_t baudRate) : SIMSerial(serial), baudRate(baudRate), commandInProgress(false), moduleReady(false), lastATAttempt(0), latitude(0.0), longitude(0.0), speed(0.0), altitude(0.0), course(0.0), satellites(0), year(0), month(0), day(0), hour(0), minute(0), second(0) {}

void SIM7600G::begin()
{
    SIMSerial.begin(baudRate);
}

void SIM7600G::update()
{
    while (SIMSerial.available())
    {
        char c = SIMSerial.read();
        responseBuffer += c;
    }

    // Step 1: Check if module is ready
    if (!moduleReady && responseBuffer.indexOf("RDY") != -1)
    {
        SIMSerial.println("ATE1"); // Enable command echo
        responseBuffer = "";
        return;
    }

    // Step 2: Ensure ATE1 response is "OK" before marking module as ready
    if (!moduleReady && responseBuffer.indexOf("OK") != -1)
    {
        moduleReady = true;
        responseBuffer = "";        
        return;
    }

    if (commandInProgress)
    {
        if (!currentCommand.echoReceived && responseBuffer.indexOf(currentCommand.command) != -1)
        {
            currentCommand.echoReceived = true;
            responseBuffer = "";            
        }

        if (currentCommand.echoReceived && responseBuffer.indexOf(currentCommand.expectedResponse) != -1)
        {
            // Check if the response is complete (ends with a newline character)
            if (responseBuffer.endsWith("\n"))
            {
                commandInProgress = false;
                if (currentCommand.command.startsWith("AT+CGPSINFO"))
                {
                    parseGPSData(responseBuffer);
                }
                currentCommand.callback(true, responseBuffer);
                responseBuffer = "";                
                processNextCommand();
            }
        }
        else if (millis() - currentCommand.startTime > currentCommand.timeout)
        {
            if (currentCommand.retryCount < COMMAND_RETRIES)
            {
                currentCommand.retryCount++;                
                SIMSerial.println(currentCommand.command);
                currentCommand.startTime = millis();
                responseBuffer = "";
            }
            else
            {
                commandInProgress = false;
                currentCommand.callback(false, "Timeout");
                responseBuffer = "";                
                processNextCommand();
            }
        }
    }
}

void SIM7600G::sendCommand(const String &command, const String &expectedResponse, uint32_t timeout, std::function<void(bool, String)> callback)
{
    Command newCommand = {command, expectedResponse, timeout, callback, millis(), false, 0};
    commandQueue.push(newCommand);
    if (!commandInProgress)
    {
        processNextCommand();
    }
}

void SIM7600G::processNextCommand()
{
    if (!commandQueue.empty() && !commandInProgress)
    {
        currentCommand = commandQueue.front();
        commandQueue.pop();
        SIMSerial.println(currentCommand.command);
        commandInProgress = true;
        responseBuffer = "";
        currentCommand.startTime = millis();
        currentCommand.retryCount = 0;
    }
}

void SIM7600G::enableGPS(std::function<void(bool, String)> callback)
{
    sendCommand("AT+CGPS=1", "OK", 5000, callback);
}

void SIM7600G::getGPSData(std::function<void(bool, String)> callback)
{
    sendCommand("AT+CGPSINFO", "+CGPSINFO:", 5000, callback);
}

void SIM7600G::parseGPSData(const String &response)
{
    int start = response.indexOf(":") + 1;
    if (start == 0)
        return;
    String data = response.substring(start);
    data.trim();

    int index = 0;
    int nextIndex = data.indexOf(',', index);
    float latitude = data.substring(index, nextIndex).toFloat();
    index = nextIndex + 1;

    char latDir = data.charAt(index);
    index += 2;

    nextIndex = data.indexOf(',', index);
    float longitude = data.substring(index, nextIndex).toFloat();
    index = nextIndex + 1;

    char lonDir = data.charAt(index);
    index += 2;

    nextIndex = data.indexOf(',', index);
    int day = data.substring(index, index + 2).toInt();
    int month = data.substring(index + 2, index + 4).toInt();
    int year = data.substring(index + 4, index + 6).toInt() + 2000;
    index = nextIndex + 1;

    nextIndex = data.indexOf(',', index);
    int hour = data.substring(index, index + 2).toInt();
    int minute = data.substring(index + 2, index + 4).toInt();
    float second = data.substring(index + 4, nextIndex).toFloat();
    index = nextIndex + 1;

    nextIndex = data.indexOf(',', index);
    float altitude = data.substring(index, nextIndex).toFloat();
    index = nextIndex + 1;

    nextIndex = data.indexOf(',', index);
    float speed = data.substring(index, nextIndex).toFloat();
    index = nextIndex + 1;

    float course = data.substring(index).toFloat();

    // Convert latitude and longitude from ddmm.mmmmmm and dddmm.mmmmmm to decimal degrees
    int latDegrees = (int)(latitude / 100);
    float latMinutes = latitude - (latDegrees * 100);
    latitude = latDegrees + (latMinutes / 60.0);

    int lonDegrees = (int)(longitude / 100);
    float lonMinutes = longitude - (lonDegrees * 100);
    longitude = lonDegrees + (lonMinutes / 60.0);

    if (latDir == 'S')
        latitude = -latitude;
    if (lonDir == 'W')
        longitude = -longitude;

    // Store the parsed date and time
    this->day = day;
    this->month = month;
    this->year = year;
    this->hour = hour;
    this->minute = minute;
    this->second = static_cast<int>(second);
    this->latitude = latitude;
    this->longitude = longitude;
    this->altitude = altitude;
    this->speed = speed;
    this->course = course;
}

void SIM7600G::initializeSIM(std::function<void(bool, String)> callback)
{
    sendCommand("AT+CPIN?", "OK", 5000, callback);
}

void SIM7600G::checkSIMStatus(std::function<void(bool, String)> callback)
{
    sendCommand("AT+CSQ", "OK", 5000, callback);
}

void SIM7600G::establishDataConnection(const char* apn, const char* user, const char* pass, std::function<void(bool, String)> callback)
{
    sendCommand("AT+CGDCONT=1,\"IP\",\"" + String(apn) + "\"", "OK", 5000, [this, apn, user, pass, callback](bool success, String response) {
        if (success) {
            sendCommand("AT+CSTT=\"" + String(apn) + "\",\"" + String(user) + "\",\"" + String(pass) + "\"", "OK", 5000, [this, callback](bool success, String response) {
                if (success) {
                    sendCommand("AT+CIICR", "OK", 10000, [this, callback](bool success, String response) {
                        if (success) {
                            sendCommand("AT+CIFSR", "", 5000, callback);
                        } else {
                            callback(false, response);
                        }
                    });
                } else {
                    callback(false, response);
                }
            });
        } else {
            callback(false, response);
        }
    });
}

void SIM7600G::httpGet(const String &url, std::function<void(bool, String)> callback)
{
    sendCommand("AT+HTTPPARA=\"URL\",\"" + url + "\"", "OK", 5000, [this, callback](bool success, String response) {
        if (success) {
            sendCommand("AT+HTTPACTION=0", "+HTTPACTION:", 10000, callback);
        } else {
            callback(false, response);
        }
    });
}

void SIM7600G::httpPost(const String &url, const String &data, std::function<void(bool, String)> callback)
{
    sendCommand("AT+HTTPPARA=\"URL\",\"" + url + "\"", "OK", 5000, [this, data, callback](bool success, String response) {
        if (success) {
            sendCommand("AT+HTTPDATA=" + String(data.length()) + ",10000", "DOWNLOAD", 10000, [this, data, callback](bool success, String response) {
                if (success) {
                    sendCommand(data, "OK", 10000, [this, callback](bool success, String response) {
                        if (success) {
                            sendCommand("AT+HTTPACTION=1", "+HTTPACTION:", 10000, callback);
                        } else {
                            callback(false, response);
                        }
                    });
                } else {
                    callback(false, response);
                }
            });
        } else {
            callback(false, response);
        }
    });
}

void SIM7600G::sendSMS(const String &number, const String &message, std::function<void(bool, String)> callback)
{
    sendCommand("AT+CSCA=\"+447782000800\"", "OK", 5000, [this, number, message, callback](bool success, String response) {
        if (success) {
            sendCommand("AT+CMGF=1", "OK", 5000, [this, number, message, callback](bool success, String response) {
                if (success) {
                    sendCommand("AT+CMGS=\"" + number + "\"", ">", 5000, [this, message, callback](bool success, String response) {
                        if (success) {
                            sendCommand(message + "\x1A", "OK", 5000, callback);
                        } else {
                            callback(false, response);
                        }
                    });
                } else {
                    callback(false, response);
                }
            });
        } else {
            callback(false, response);
        }
    });
}

void SIM7600G::mqttConnect(const String &server, int port, std::function<void(bool, String)> callback)
{
    sendCommand("AT+MQTTCONNECT=\"" + server + "\"," + String(port), "OK", 10000, callback);
}

void SIM7600G::mqttPublish(const String &topic, const String &message, std::function<void(bool, String)> callback)
{
    sendCommand("AT+MQTTPUB=\"" + topic + "\",\"" + message + "\"", "OK", 5000, callback);
}

void SIM7600G::mqttSubscribe(const String &topic, std::function<void(bool, String)> callback)
{
    sendCommand("AT+MQTTSUB=\"" + topic + "\"", "OK", 5000, callback);
}

void SIM7600G::ping(const String &host, std::function<void(bool, String)> callback)
{
    sendCommand("AT+PING=\"" + host + "\"", "+PING:", 10000, callback);
}

void SIM7600G::checkGPSFix(std::function<void(bool, String)> callback)
{
    sendCommand("AT+CGPSSTATUS?", "OK", 5000, [this, callback](bool success, String response) {
        if (success) {
            if (response.indexOf("Location 3D Fix") != -1 || response.indexOf("Location 2D Fix") != -1) {
                callback(true, "GPS Fix acquired");
            } else {
                callback(false, "No GPS Fix");
            }
        } else {
            callback(false, response);
        }
    });
}
